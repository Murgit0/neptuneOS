#!/bin/bash
set -e

echo "🔧 Setting up NeptuneOS ISO build environment..."

sudo apt update && sudo apt install -y \
  live-build debootstrap squashfs-tools xorriso grub-pc-bin grub-efi-amd64-bin \
  systemd-sysv syslinux-utils isolinux wget curl git unzip clang make cmake \
  bubblewrap flatpak snapd clamav clamav-daemon portmaster qemu-kvm libvirt-daemon-system \
  wine winetricks sddm konsole calamares kde-plasma-desktop gnome-session

mkdir -p neptune_iso_build/config/includes.chroot
mkdir -p neptune_iso_build/config/hooks
mkdir -p neptune_iso_build/config/package-lists
mkdir -p neptune_iso_build/config/bootloaders
mkdir -p neptune_iso_build/config/filesystem.binary

cd neptune_iso_build

lb config \
  --distribution focal \
  --archive-areas "main restricted universe multiverse" \
  --debian-installer live \
  --binary-images iso-hybrid \
  --bootappend-live "boot=live components quiet splash" \
  --iso-application "NeptuneOS" \
  --iso-publisher "Neptune Project" \
  --iso-volume "NeptuneOS Installer" \
  --architectures amd64

mkdir -p config/includes.chroot/boot/grub/themes/neptune
cp -r ../boot_grub_themes_neptune/* config/includes.chroot/boot/grub/themes/neptune

mkdir -p config/includes.chroot/usr/share/neptune/help/
echo "Welcome to NeptuneOS Help Center" > config/includes.chroot/usr/share/neptune/help/index.txt

mkdir -p config/includes.chroot/usr/bin
echo -e "#!/bin/bash\necho 'npkg mock running...'" > config/includes.chroot/usr/bin/npkg
chmod +x config/includes.chroot/usr/bin/npkg

echo -e "#!/bin/bash\necho 'Neptune Messenger mock running...'" > config/includes.chroot/usr/bin/neptune-messenger
chmod +x config/includes.chroot/usr/bin/neptune-messenger

echo "🚀 Building NeptuneOS ISO... (this may take a while)"
sudo lb build
